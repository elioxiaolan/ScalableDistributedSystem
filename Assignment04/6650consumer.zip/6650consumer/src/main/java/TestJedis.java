import com.google.gson.Gson;
import com.google.gson.JsonObject;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;

public class TestJedis {

  public static void main(String[] args) {
    JedisPool pool = new JedisPool("54.202.55.154", 6379);

    Gson gson=new Gson();
    JsonObject values=new JsonObject();
    values.addProperty("LiftRide",1);
    values.addProperty("SkierID","2");
    System.out.println(gson.toJson(values));

    try (Jedis jedis = pool.getResource()) {
      //jedis.get()
    }
  }

}
