package model;

public class Comment {

  public static String SESSION_DAYS="session_days";

  public static String VERTICAL_TOTAL="vertical_total";

  public static String LIFT_RODE="lift_rode";

  public static String UNIQUE_SKIERS="unique_skiers";

}
